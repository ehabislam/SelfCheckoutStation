package unSorted;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemberDatabase {

	public static final Map<String, List<String>> MEMBER_DATABASE = new HashMap<>();
}
