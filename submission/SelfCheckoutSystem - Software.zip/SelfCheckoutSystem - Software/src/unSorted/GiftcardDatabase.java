package unSorted;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
/**
 * maps card numbers to their Balance * 
 * 
 * @author Ehab
 *
 */
public class GiftcardDatabase {
	public static final Map<String, BigDecimal> GIFTCARD_DATABASE = new HashMap<>();
}
