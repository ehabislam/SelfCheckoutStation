package attendantConsole;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class EmployeeDatabase {
	
	public static final Map<String, ArrayList<String>> EMPLOYEE_DATABASE = new HashMap<>();

}
