package gui;

import java.util.ArrayList;

import unSorted.SelfCheckoutStationInstance;

public class GUIHelper {
	static ArrayList<SelfCheckoutStationInstance> stationList= new ArrayList<SelfCheckoutStationInstance>();

	public static ArrayList<SelfCheckoutStationInstance> getStationList() {
		return stationList;
	}
	
}
