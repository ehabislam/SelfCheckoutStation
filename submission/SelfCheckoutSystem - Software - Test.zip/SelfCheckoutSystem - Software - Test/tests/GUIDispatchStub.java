import gui.StationPanel;
import unSorted.GUIDispatch;

public class GUIDispatchStub extends GUIDispatch {

	public GUIDispatchStub(StationPanel stationpanel) {
		super(stationpanel);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void updateMaintenanceList(int stationId) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void updateItemListPanel() {
		
	}
	
	
	

}
